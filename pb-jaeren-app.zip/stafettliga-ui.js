// ════════════════════════════════════════════════════════
// stafettliga-ui.js — Oversikt, oppsett og tabell
// Live kampregistrering ligger i stafettliga-spill-ui.js.
// ════════════════════════════════════════════════════════

import { escHtml, visMelding } from './ui.js';
import { renderMetaChip, renderTomTilstand } from './render-helpers.js';
import {
  opprettSesong, startSesong, hentSesong, hentAktiveSesonger,
  beregnLagoppsett,
} from './stafettliga.js';

// ── Avhengigheter injisert fra app.js ────────────────────
let _naviger         = () => {};
let _krevAdmin       = () => {};
let _getAktivKlubbId = () => null;

export function stafettligaUIInit(deps) {
  _naviger         = deps.naviger;
  _krevAdmin       = deps.krevAdmin;
  _getAktivKlubbId = deps.getAktivKlubbId;
}

let _aktivSesongId = null;
export function getAktivStafettligaSesongId() { return _aktivSesongId; }

// ════════════════════════════════════════════════════════
// OVERSIKT
// ════════════════════════════════════════════════════════
export async function visStafettligaOversikt() {
  _naviger('stafettliga-oversikt');
  const container = document.getElementById('stafettliga-oversikt-innhold');
  container.innerHTML = '<div class="tom-tilstand-liten">Laster …</div>';

  const sesonger = await hentAktiveSesonger();
  if (!sesonger.length) {
    container.innerHTML = renderTomTilstand('Ingen aktive sesonger ennå. Trykk «+ Ny» for å starte en Stafettliga-kveld.', true);
    return;
  }

  container.innerHTML = sesonger.map(s => `
    <div class="t-lag-element" style="cursor:pointer;margin-bottom:8px" onclick="window.apneStafettligaSesong?.('${s.id}')">
      <div style="flex:1">
        <div style="font-size:17px;font-weight:600">${escHtml(s.navn)}</div>
        <div style="font-size:13px;color:var(--muted2);margin-top:2px">
          ${s.antallLag} lag · ${escHtml(s.status)}
        </div>
      </div>
      <span class="t-status-merke ${s.status === 'aktiv' ? 'ts-aktiv' : 'ts-setup'}">${escHtml(s.status)}</span>
    </div>
  `).join('');
}
window.visStafettligaOversikt = visStafettligaOversikt;

export async function apneStafettligaSesong(sesongId) {
  _aktivSesongId = sesongId;
  const sesong = await hentSesong(sesongId);
  if (sesong.status === 'oppsett') {
    // Ikke startet ennå — tilbake til oppsettskjermen (enkel MVP: åpne tabellskjerm uansett,
    // admin kan trykke "Start sesong" der).
  }
  await visStafettligaTabell(sesongId);
}
window.apneStafettligaSesong = apneStafettligaSesong;

// ════════════════════════════════════════════════════════
// OPPSETT
// ════════════════════════════════════════════════════════
export function opprettStafettligaSesong() {
  _krevAdmin('Ny sesong', 'Kun admin kan opprette en ny Stafettliga-sesong.', () => {
    _naviger('stafettliga-oppsett');
    renderOppsettSteg1();
  });
}
window.opprettStafettligaSesong = opprettStafettligaSesong;

function renderOppsettSteg1() {
  const container = document.getElementById('stafettliga-oppsett-innhold');
  container.innerHTML = `
    <div style="padding:16px">
      <label style="font-size:14px;color:var(--muted2)">Navn på sesongen</label>
      <input id="sl-navn" type="text" placeholder="Stafettligaen — torsdag" style="width:100%;margin:6px 0 16px">

      <label style="font-size:14px;color:var(--muted2)">Antall deltakere (16–28)</label>
      <input id="sl-antall" type="number" min="16" max="28" placeholder="F.eks. 22" style="width:100%;margin:6px 0 8px"
             oninput="window.oppdaterStafettligaRegelVisning?.()">

      <div id="sl-regel-info"></div>

      <button class="knapp knapp-primaer" style="width:100%;margin-top:12px" onclick="window.gaTilLagoppsett?.()">
        Neste — sett opp lag
      </button>
    </div>
  `;
}

window.oppdaterStafettligaRegelVisning = function () {
  const antall = parseInt(document.getElementById('sl-antall')?.value, 10);
  const infoEl = document.getElementById('sl-regel-info');
  if (!infoEl) return;
  if (isNaN(antall) || antall < 16 || antall > 28) {
    infoEl.innerHTML = '';
    return;
  }
  try {
    const { antallLag, lagStorrelser, regel } = beregnLagoppsett(antall);
    infoEl.innerHTML = `
      <div class="sl-regel-boks">
        <strong>${antallLag} lag</strong> · lagstørrelser: <strong>${lagStorrelser.join(' + ')}</strong> · Regel <strong>${regel}</strong>
      </div>`;
  } catch (e) {
    infoEl.innerHTML = `<div class="sl-regel-boks" style="color:var(--red2)">${escHtml(e.message)}</div>`;
  }
};

window.gaTilLagoppsett = function () {
  const navn   = document.getElementById('sl-navn')?.value?.trim();
  const antall = parseInt(document.getElementById('sl-antall')?.value, 10);
  let oppsett;
  try {
    oppsett = beregnLagoppsett(antall);
  } catch (e) {
    visMelding(e.message, 'feil');
    return;
  }
  renderOppsettSteg2(navn, antall, oppsett);
};

function renderOppsettSteg2(navn, antallDeltakere, oppsett) {
  const container = document.getElementById('stafettliga-oppsett-innhold');
  const { antallLag, lagStorrelser } = oppsett;

  const lagHtml = lagStorrelser.map((storrelse, i) => {
    const niva1Standard = Math.ceil(storrelse / 2);
    const niva2Standard = storrelse - niva1Standard;
    return `
      <div class="t-lag-element" style="flex-direction:column;align-items:stretch;gap:8px;padding:14px">
        <input class="sl-lagnavn" type="text" value="Lag ${i + 1}" style="font-size:16px;font-weight:600" data-lag-idx="${i}">
        <div style="font-size:12px;color:var(--muted2)">${storrelse} spillere totalt — fordel på nivå 1/nivå 2 under (kommaseparert navn)</div>
        <div>
          <span class="sl-niva-merke sl-niva-1">1</span>
          <input class="sl-niva1-spillere" type="text" placeholder="Navn, Navn${niva1Standard === 3 ? ', Navn' : ''}"
                 data-lag-idx="${i}" style="width:calc(100% - 34px)">
        </div>
        <div>
          <span class="sl-niva-merke sl-niva-2">2</span>
          <input class="sl-niva2-spillere" type="text" placeholder="Navn, Navn${niva2Standard === 3 ? ', Navn' : ''}"
                 data-lag-idx="${i}" style="width:calc(100% - 34px)">
        </div>
      </div>
    `;
  }).join('');

  container.innerHTML = `
    <div style="padding:16px">
      <div class="sl-regel-boks">Fyll inn spillernavn for hvert lag. Antall navn på nivå1 + nivå2 må stemme med lagstørrelsen.</div>
      ${lagHtml}
      <button class="knapp knapp-primaer" style="width:100%;margin-top:8px"
              onclick="window.lagreStafettligaOppsett?.('${escHtml(navn)}', ${antallDeltakere}, ${antallLag}, ${JSON.stringify(lagStorrelser)})">
        Opprett og start sesong
      </button>
    </div>
  `;
}

window.lagreStafettligaOppsett = async function (navn, antallDeltakere, antallLag, lagStorrelser) {
  const lag = [];
  for (let i = 0; i < antallLag; i++) {
    const navnEl  = document.querySelector(`.sl-lagnavn[data-lag-idx="${i}"]`);
    const n1El    = document.querySelector(`.sl-niva1-spillere[data-lag-idx="${i}"]`);
    const n2El    = document.querySelector(`.sl-niva2-spillere[data-lag-idx="${i}"]`);
    const niva1   = (n1El?.value ?? '').split(',').map(s => s.trim()).filter(Boolean);
    const niva2   = (n2El?.value ?? '').split(',').map(s => s.trim()).filter(Boolean);
    const forventet = lagStorrelser[i];

    if (niva1.length + niva2.length !== forventet) {
      visMelding(`${navnEl?.value ?? 'Lag ' + (i + 1)}: forventet ${forventet} spillere totalt, fikk ${niva1.length + niva2.length}.`, 'feil');
      return;
    }
    lag.push({ navn: navnEl?.value?.trim() || `Lag ${i + 1}`, spillere: { niva1, niva2 } });
  }

  try {
    const sesongId = await opprettSesong({ navn, antallDeltakere, lag });
    await startSesong(sesongId);
    _aktivSesongId = sesongId;
    await visStafettligaTabell(sesongId);
  } catch (e) {
    visMelding(e.message, 'feil');
  }
};

// ════════════════════════════════════════════════════════
// TABELL
// ════════════════════════════════════════════════════════
export async function visStafettligaTabell(sesongId) {
  _aktivSesongId = sesongId;
  _naviger('stafettliga-tabell');
  const container = document.getElementById('stafettliga-tabell-innhold');
  container.innerHTML = '<div class="tom-tilstand-liten">Laster …</div>';

  const sesong = await hentSesong(sesongId);
  const tabell = sesong.tabell ?? [];

  const chips = renderMetaChip('🏆', sesong.navn) + renderMetaChip('👥', `${sesong.antallLag} lag`);

  const tabellHtml = tabell.length
    ? tabell.map(r => `
        <div class="sl-tabell-rad">
          <div class="sl-tabell-plass">${r.plass}</div>
          <div class="sl-tabell-navn">${escHtml(r.navn)}</div>
          <div class="sl-tabell-prosent">${r.poengprosent.toFixed(1)}%</div>
          <div class="sl-tabell-poeng">${r.lagpoeng}</div>
        </div>
      `).join('')
    : renderTomTilstand('Ingen resultater registrert ennå.');

  container.innerHTML = `
    <div style="display:flex;gap:8px;flex-wrap:wrap;padding:14px 16px 0">${chips}</div>
    <div style="margin-top:10px">${tabellHtml}</div>
    <div style="padding:16px">
      <button class="knapp knapp-omriss" style="width:100%" onclick="window.visStafettligaLagkamper?.('${sesongId}')">
        Se lagkamper
      </button>
    </div>
  `;
}
window.tilbakeTilStafettligaSesong = () => { if (_aktivSesongId) visStafettligaTabell(_aktivSesongId); };
